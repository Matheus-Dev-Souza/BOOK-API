// @ts-ignore
import React from 'react';
import TemplatePage from '../templates/TemplatePage'

const Films = () => {
    return (
        <TemplatePage name={'Films'} api={'all-films'} />
    );
};

export default Films;
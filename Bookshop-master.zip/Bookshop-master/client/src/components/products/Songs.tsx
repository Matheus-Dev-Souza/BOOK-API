// @ts-ignore
import React from 'react';
import TemplatePage from '../templates/TemplatePage'

const Songs = () => {
    return (
        <TemplatePage name={'Songs'} api={'all-songs'} />
    );
};

export default Songs;
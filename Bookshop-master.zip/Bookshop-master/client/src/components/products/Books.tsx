// @ts-ignore
import React from 'react';
import TemplatePage from '../templates/TemplatePage'

const Books = () => {
    return (
        <TemplatePage name={'Books'} api={'all-books'} />
    );
};

export default Books;
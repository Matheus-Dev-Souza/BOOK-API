# Insights

### Home 

<img src="./Home.png">

### Basket

<img src="./Basket.png">

### Detailed Product

<img src="./DetailedProduct.png">

### Register & Login

TODO

### Profile

TODO